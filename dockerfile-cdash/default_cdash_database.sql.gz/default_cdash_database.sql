-- MySQL dump 10.13  Distrib 5.5.47, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: cdash
-- ------------------------------------------------------
-- Server version	5.5.47-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apitoken`
--

DROP TABLE IF EXISTS `apitoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apitoken` (
  `projectid` int(11) NOT NULL,
  `token` varchar(40) DEFAULT NULL,
  `expiration_date` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  KEY `token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apitoken`
--

LOCK TABLES `apitoken` WRITE;
/*!40000 ALTER TABLE `apitoken` DISABLE KEYS */;
/*!40000 ALTER TABLE `apitoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banner`
--

DROP TABLE IF EXISTS `banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banner` (
  `projectid` int(11) NOT NULL,
  `text` varchar(500) NOT NULL,
  PRIMARY KEY (`projectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banner`
--

LOCK TABLES `banner` WRITE;
/*!40000 ALTER TABLE `banner` DISABLE KEYS */;
/*!40000 ALTER TABLE `banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blockbuild`
--

DROP TABLE IF EXISTS `blockbuild`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blockbuild` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  `buildname` varchar(255) NOT NULL,
  `sitename` varchar(255) NOT NULL,
  `ipaddress` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `projectid` (`projectid`),
  KEY `buildname` (`buildname`),
  KEY `sitename` (`sitename`),
  KEY `ipaddress` (`ipaddress`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blockbuild`
--

LOCK TABLES `blockbuild` WRITE;
/*!40000 ALTER TABLE `blockbuild` DISABLE KEYS */;
/*!40000 ALTER TABLE `blockbuild` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `build`
--

DROP TABLE IF EXISTS `build`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `build` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteid` int(11) NOT NULL DEFAULT '0',
  `projectid` int(11) NOT NULL DEFAULT '0',
  `stamp` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT '',
  `generator` varchar(255) NOT NULL DEFAULT '',
  `starttime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `endtime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `submittime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `command` text NOT NULL,
  `log` text NOT NULL,
  `builderrors` smallint(6) DEFAULT '-1',
  `buildwarnings` smallint(6) DEFAULT '-1',
  `testnotrun` smallint(6) DEFAULT '-1',
  `testfailed` smallint(6) DEFAULT '-1',
  `testpassed` smallint(6) DEFAULT '-1',
  `testtimestatusfailed` smallint(6) DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `projectid` (`projectid`),
  KEY `starttime` (`starttime`),
  KEY `submittime` (`submittime`),
  KEY `siteid` (`siteid`),
  KEY `stamp` (`stamp`),
  KEY `type` (`type`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `build`
--

LOCK TABLES `build` WRITE;
/*!40000 ALTER TABLE `build` DISABLE KEYS */;
/*!40000 ALTER TABLE `build` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `build2group`
--

DROP TABLE IF EXISTS `build2group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `build2group` (
  `groupid` int(11) NOT NULL DEFAULT '0',
  `buildid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`buildid`),
  KEY `groupid` (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `build2group`
--

LOCK TABLES `build2group` WRITE;
/*!40000 ALTER TABLE `build2group` DISABLE KEYS */;
/*!40000 ALTER TABLE `build2group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `build2grouprule`
--

DROP TABLE IF EXISTS `build2grouprule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `build2grouprule` (
  `groupid` int(11) NOT NULL DEFAULT '0',
  `buildtype` varchar(20) NOT NULL DEFAULT '',
  `buildname` varchar(255) NOT NULL DEFAULT '',
  `siteid` int(11) NOT NULL DEFAULT '0',
  `expected` tinyint(4) NOT NULL DEFAULT '0',
  `starttime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `endtime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  KEY `groupid` (`groupid`),
  KEY `buildtype` (`buildtype`),
  KEY `buildname` (`buildname`),
  KEY `siteid` (`siteid`),
  KEY `expected` (`expected`),
  KEY `starttime` (`starttime`),
  KEY `endtime` (`endtime`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `build2grouprule`
--

LOCK TABLES `build2grouprule` WRITE;
/*!40000 ALTER TABLE `build2grouprule` DISABLE KEYS */;
/*!40000 ALTER TABLE `build2grouprule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `build2note`
--

DROP TABLE IF EXISTS `build2note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `build2note` (
  `buildid` bigint(20) NOT NULL,
  `noteid` bigint(20) NOT NULL,
  `time` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  KEY `buildid` (`buildid`),
  KEY `noteid` (`noteid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `build2note`
--

LOCK TABLES `build2note` WRITE;
/*!40000 ALTER TABLE `build2note` DISABLE KEYS */;
/*!40000 ALTER TABLE `build2note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `build2test`
--

DROP TABLE IF EXISTS `build2test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `build2test` (
  `buildid` int(11) NOT NULL DEFAULT '0',
  `testid` int(11) NOT NULL DEFAULT '0',
  `status` varchar(10) NOT NULL DEFAULT '',
  `time` float(7,2) NOT NULL DEFAULT '0.00',
  `timemean` float(7,2) NOT NULL DEFAULT '0.00',
  `timestd` float(7,2) NOT NULL DEFAULT '0.00',
  `timestatus` tinyint(4) NOT NULL DEFAULT '0',
  `newstatus` tinyint(4) NOT NULL DEFAULT '0',
  KEY `buildid` (`buildid`),
  KEY `testid` (`testid`),
  KEY `status` (`status`),
  KEY `timestatus` (`timestatus`),
  KEY `newstatus` (`newstatus`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `build2test`
--

LOCK TABLES `build2test` WRITE;
/*!40000 ALTER TABLE `build2test` DISABLE KEYS */;
/*!40000 ALTER TABLE `build2test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `build2update`
--

DROP TABLE IF EXISTS `build2update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `build2update` (
  `buildid` bigint(11) NOT NULL,
  `updateid` bigint(11) NOT NULL,
  PRIMARY KEY (`buildid`),
  KEY `updateid` (`updateid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `build2update`
--

LOCK TABLES `build2update` WRITE;
/*!40000 ALTER TABLE `build2update` DISABLE KEYS */;
/*!40000 ALTER TABLE `build2update` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `build2uploadfile`
--

DROP TABLE IF EXISTS `build2uploadfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `build2uploadfile` (
  `fileid` bigint(11) NOT NULL,
  `buildid` bigint(11) NOT NULL,
  KEY `fileid` (`fileid`),
  KEY `buildid` (`buildid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `build2uploadfile`
--

LOCK TABLES `build2uploadfile` WRITE;
/*!40000 ALTER TABLE `build2uploadfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `build2uploadfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buildemail`
--

DROP TABLE IF EXISTS `buildemail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buildemail` (
  `userid` int(11) NOT NULL,
  `buildid` bigint(20) NOT NULL,
  `category` tinyint(4) NOT NULL,
  `time` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  KEY `userid` (`userid`),
  KEY `buildid` (`buildid`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buildemail`
--

LOCK TABLES `buildemail` WRITE;
/*!40000 ALTER TABLE `buildemail` DISABLE KEYS */;
/*!40000 ALTER TABLE `buildemail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `builderror`
--

DROP TABLE IF EXISTS `builderror`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `builderror` (
  `buildid` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(4) NOT NULL DEFAULT '0',
  `logline` int(11) NOT NULL DEFAULT '0',
  `text` text NOT NULL,
  `sourcefile` varchar(255) NOT NULL DEFAULT '',
  `sourceline` int(11) NOT NULL DEFAULT '0',
  `precontext` text,
  `postcontext` text,
  `repeatcount` int(11) NOT NULL DEFAULT '0',
  `crc32` bigint(20) NOT NULL DEFAULT '0',
  `newstatus` tinyint(4) NOT NULL DEFAULT '0',
  KEY `buildid` (`buildid`),
  KEY `type` (`type`),
  KEY `crc32` (`crc32`),
  KEY `newstatus` (`newstatus`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 MAX_ROWS=4294967295 AVG_ROW_LENGTH=3458;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `builderror`
--

LOCK TABLES `builderror` WRITE;
/*!40000 ALTER TABLE `builderror` DISABLE KEYS */;
/*!40000 ALTER TABLE `builderror` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `builderrordiff`
--

DROP TABLE IF EXISTS `builderrordiff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `builderrordiff` (
  `buildid` bigint(20) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `difference_positive` int(11) NOT NULL,
  `difference_negative` int(11) NOT NULL,
  KEY `buildid` (`buildid`),
  KEY `type` (`type`),
  KEY `difference_positive` (`difference_positive`),
  KEY `difference_negative` (`difference_negative`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `builderrordiff`
--

LOCK TABLES `builderrordiff` WRITE;
/*!40000 ALTER TABLE `builderrordiff` DISABLE KEYS */;
/*!40000 ALTER TABLE `builderrordiff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buildfailure`
--

DROP TABLE IF EXISTS `buildfailure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buildfailure` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `buildid` bigint(20) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `workingdirectory` varchar(255) NOT NULL,
  `stdoutput` mediumtext NOT NULL,
  `stderror` mediumtext NOT NULL,
  `exitcondition` varchar(255) NOT NULL,
  `language` varchar(64) NOT NULL,
  `targetname` varchar(255) NOT NULL,
  `outputfile` varchar(255) NOT NULL,
  `outputtype` varchar(255) NOT NULL,
  `sourcefile` varchar(512) NOT NULL,
  `crc32` bigint(20) NOT NULL DEFAULT '0',
  `newstatus` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `buildid` (`buildid`),
  KEY `type` (`type`),
  KEY `crc32` (`crc32`),
  KEY `newstatus` (`newstatus`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buildfailure`
--

LOCK TABLES `buildfailure` WRITE;
/*!40000 ALTER TABLE `buildfailure` DISABLE KEYS */;
/*!40000 ALTER TABLE `buildfailure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buildfailure2argument`
--

DROP TABLE IF EXISTS `buildfailure2argument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buildfailure2argument` (
  `buildfailureid` bigint(20) NOT NULL,
  `argumentid` bigint(20) NOT NULL,
  `place` int(11) NOT NULL DEFAULT '0',
  KEY `argumentid` (`argumentid`),
  KEY `buildfailureid` (`buildfailureid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buildfailure2argument`
--

LOCK TABLES `buildfailure2argument` WRITE;
/*!40000 ALTER TABLE `buildfailure2argument` DISABLE KEYS */;
/*!40000 ALTER TABLE `buildfailure2argument` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buildfailureargument`
--

DROP TABLE IF EXISTS `buildfailureargument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buildfailureargument` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `argument` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `argument` (`argument`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buildfailureargument`
--

LOCK TABLES `buildfailureargument` WRITE;
/*!40000 ALTER TABLE `buildfailureargument` DISABLE KEYS */;
/*!40000 ALTER TABLE `buildfailureargument` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buildgroup`
--

DROP TABLE IF EXISTS `buildgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buildgroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `projectid` int(11) NOT NULL DEFAULT '0',
  `starttime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `endtime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `autoremovetimeframe` int(11) DEFAULT '0',
  `description` text NOT NULL,
  `summaryemail` tinyint(4) DEFAULT '0',
  `includesubprojectotal` tinyint(4) DEFAULT '1',
  `emailcommitters` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `projectid` (`projectid`),
  KEY `starttime` (`starttime`),
  KEY `endtime` (`endtime`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buildgroup`
--

LOCK TABLES `buildgroup` WRITE;
/*!40000 ALTER TABLE `buildgroup` DISABLE KEYS */;
INSERT INTO `buildgroup` VALUES (1,'Nightly',1,'1980-01-01 07:00:00','1980-01-01 07:00:00',0,'Nightly builds',0,1,0),(2,'Continuous',1,'1980-01-01 07:00:00','1980-01-01 07:00:00',0,'Continuous builds',0,1,0),(3,'Experimental',1,'1980-01-01 07:00:00','1980-01-01 07:00:00',0,'Experimental builds',0,1,0),(4,'Nightly',2,'1980-01-01 07:00:00','1980-01-01 07:00:00',0,'Nightly builds',0,1,0),(5,'Continuous',2,'1980-01-01 07:00:00','1980-01-01 07:00:00',0,'Continuous builds',0,1,0),(6,'Experimental',2,'1980-01-01 07:00:00','1980-01-01 07:00:00',0,'Experimental builds',0,1,0),(7,'Nightly',3,'1980-01-01 07:00:00','1980-01-01 07:00:00',0,'Nightly builds',0,1,0),(8,'Continuous',3,'1980-01-01 07:00:00','1980-01-01 07:00:00',0,'Continuous builds',0,1,0),(9,'Experimental',3,'1980-01-01 07:00:00','1980-01-01 07:00:00',0,'Experimental builds',0,1,0);
/*!40000 ALTER TABLE `buildgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buildgroupposition`
--

DROP TABLE IF EXISTS `buildgroupposition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buildgroupposition` (
  `buildgroupid` int(11) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL DEFAULT '0',
  `starttime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `endtime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  KEY `buildgroupid` (`buildgroupid`),
  KEY `endtime` (`endtime`),
  KEY `starttime` (`starttime`),
  KEY `position` (`position`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buildgroupposition`
--

LOCK TABLES `buildgroupposition` WRITE;
/*!40000 ALTER TABLE `buildgroupposition` DISABLE KEYS */;
INSERT INTO `buildgroupposition` VALUES (1,1,'1980-01-01 07:00:00','1980-01-01 07:00:00'),(2,2,'1980-01-01 07:00:00','1980-01-01 07:00:00'),(3,3,'1980-01-01 07:00:00','1980-01-01 07:00:00'),(4,1,'1980-01-01 07:00:00','1980-01-01 07:00:00'),(5,2,'1980-01-01 07:00:00','1980-01-01 07:00:00'),(6,3,'1980-01-01 07:00:00','1980-01-01 07:00:00'),(7,1,'1980-01-01 07:00:00','1980-01-01 07:00:00'),(8,2,'1980-01-01 07:00:00','1980-01-01 07:00:00'),(9,3,'1980-01-01 07:00:00','1980-01-01 07:00:00');
/*!40000 ALTER TABLE `buildgroupposition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buildinformation`
--

DROP TABLE IF EXISTS `buildinformation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buildinformation` (
  `buildid` int(11) NOT NULL,
  `osname` varchar(255) NOT NULL,
  `osplatform` varchar(255) NOT NULL,
  `osrelease` varchar(255) NOT NULL,
  `osversion` varchar(255) NOT NULL,
  `compilername` varchar(255) NOT NULL,
  `compilerversion` varchar(20) NOT NULL,
  PRIMARY KEY (`buildid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buildinformation`
--

LOCK TABLES `buildinformation` WRITE;
/*!40000 ALTER TABLE `buildinformation` DISABLE KEYS */;
/*!40000 ALTER TABLE `buildinformation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buildnote`
--

DROP TABLE IF EXISTS `buildnote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buildnote` (
  `buildid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `note` mediumtext NOT NULL,
  `timestamp` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  KEY `buildid` (`buildid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 MAX_ROWS=4294967295 AVG_ROW_LENGTH=3458;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buildnote`
--

LOCK TABLES `buildnote` WRITE;
/*!40000 ALTER TABLE `buildnote` DISABLE KEYS */;
/*!40000 ALTER TABLE `buildnote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buildtesttime`
--

DROP TABLE IF EXISTS `buildtesttime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buildtesttime` (
  `buildid` int(11) NOT NULL DEFAULT '0',
  `time` float(7,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`buildid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buildtesttime`
--

LOCK TABLES `buildtesttime` WRITE;
/*!40000 ALTER TABLE `buildtesttime` DISABLE KEYS */;
/*!40000 ALTER TABLE `buildtesttime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buildupdate`
--

DROP TABLE IF EXISTS `buildupdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buildupdate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `starttime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `endtime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `command` text NOT NULL,
  `type` varchar(4) NOT NULL DEFAULT '',
  `status` text NOT NULL,
  `nfiles` smallint(6) DEFAULT '-1',
  `warnings` smallint(6) DEFAULT '-1',
  `revision` varchar(60) NOT NULL DEFAULT '0',
  `priorrevision` varchar(60) NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buildupdate`
--

LOCK TABLES `buildupdate` WRITE;
/*!40000 ALTER TABLE `buildupdate` DISABLE KEYS */;
/*!40000 ALTER TABLE `buildupdate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_cmake`
--

DROP TABLE IF EXISTS `client_cmake`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_cmake` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_cmake`
--

LOCK TABLES `client_cmake` WRITE;
/*!40000 ALTER TABLE `client_cmake` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_cmake` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_compiler`
--

DROP TABLE IF EXISTS `client_compiler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_compiler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_compiler`
--

LOCK TABLES `client_compiler` WRITE;
/*!40000 ALTER TABLE `client_compiler` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_compiler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_job`
--

DROP TABLE IF EXISTS `client_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_job` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scheduleid` bigint(20) NOT NULL,
  `osid` tinyint(4) NOT NULL,
  `siteid` int(11) DEFAULT NULL,
  `startdate` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `enddate` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `status` int(11) DEFAULT NULL,
  `output` text,
  `cmakeid` int(11) NOT NULL,
  `compilerid` int(11) NOT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `scheduleid` (`scheduleid`),
  KEY `startdate` (`startdate`),
  KEY `enddate` (`enddate`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_job`
--

LOCK TABLES `client_job` WRITE;
/*!40000 ALTER TABLE `client_job` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_jobschedule`
--

DROP TABLE IF EXISTS `client_jobschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_jobschedule` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `projectid` int(11) DEFAULT NULL,
  `cmakecache` mediumtext NOT NULL,
  `clientscript` text,
  `startdate` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `enddate` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `type` tinyint(4) NOT NULL,
  `starttime` time NOT NULL DEFAULT '00:00:00',
  `repeattime` decimal(6,2) NOT NULL DEFAULT '0.00',
  `enable` tinyint(4) NOT NULL,
  `lastrun` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `repository` varchar(512) DEFAULT '',
  `module` varchar(255) DEFAULT '',
  `buildnamesuffix` varchar(255) DEFAULT '',
  `tag` varchar(255) DEFAULT '',
  `buildconfiguration` tinyint(4) DEFAULT '0',
  `description` text,
  UNIQUE KEY `id` (`id`),
  KEY `userid` (`userid`),
  KEY `projectid` (`projectid`),
  KEY `enable` (`enable`),
  KEY `starttime` (`starttime`),
  KEY `repeattime` (`repeattime`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_jobschedule`
--

LOCK TABLES `client_jobschedule` WRITE;
/*!40000 ALTER TABLE `client_jobschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_jobschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_jobschedule2build`
--

DROP TABLE IF EXISTS `client_jobschedule2build`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_jobschedule2build` (
  `scheduleid` bigint(20) unsigned NOT NULL,
  `buildid` int(11) NOT NULL,
  UNIQUE KEY `scheduleid` (`scheduleid`,`buildid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_jobschedule2build`
--

LOCK TABLES `client_jobschedule2build` WRITE;
/*!40000 ALTER TABLE `client_jobschedule2build` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_jobschedule2build` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_jobschedule2cmake`
--

DROP TABLE IF EXISTS `client_jobschedule2cmake`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_jobschedule2cmake` (
  `scheduleid` bigint(20) NOT NULL,
  `cmakeid` int(11) NOT NULL,
  UNIQUE KEY `scheduleid` (`scheduleid`,`cmakeid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_jobschedule2cmake`
--

LOCK TABLES `client_jobschedule2cmake` WRITE;
/*!40000 ALTER TABLE `client_jobschedule2cmake` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_jobschedule2cmake` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_jobschedule2compiler`
--

DROP TABLE IF EXISTS `client_jobschedule2compiler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_jobschedule2compiler` (
  `scheduleid` bigint(20) NOT NULL,
  `compilerid` int(11) NOT NULL,
  UNIQUE KEY `scheduleid` (`scheduleid`,`compilerid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_jobschedule2compiler`
--

LOCK TABLES `client_jobschedule2compiler` WRITE;
/*!40000 ALTER TABLE `client_jobschedule2compiler` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_jobschedule2compiler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_jobschedule2library`
--

DROP TABLE IF EXISTS `client_jobschedule2library`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_jobschedule2library` (
  `scheduleid` bigint(20) NOT NULL,
  `libraryid` int(11) NOT NULL,
  UNIQUE KEY `scheduleid` (`scheduleid`,`libraryid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_jobschedule2library`
--

LOCK TABLES `client_jobschedule2library` WRITE;
/*!40000 ALTER TABLE `client_jobschedule2library` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_jobschedule2library` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_jobschedule2os`
--

DROP TABLE IF EXISTS `client_jobschedule2os`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_jobschedule2os` (
  `scheduleid` bigint(20) NOT NULL,
  `osid` int(11) NOT NULL,
  UNIQUE KEY `scheduleid` (`scheduleid`,`osid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_jobschedule2os`
--

LOCK TABLES `client_jobschedule2os` WRITE;
/*!40000 ALTER TABLE `client_jobschedule2os` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_jobschedule2os` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_jobschedule2site`
--

DROP TABLE IF EXISTS `client_jobschedule2site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_jobschedule2site` (
  `scheduleid` bigint(20) NOT NULL,
  `siteid` int(11) NOT NULL,
  UNIQUE KEY `scheduleid` (`scheduleid`,`siteid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_jobschedule2site`
--

LOCK TABLES `client_jobschedule2site` WRITE;
/*!40000 ALTER TABLE `client_jobschedule2site` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_jobschedule2site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_jobschedule2submission`
--

DROP TABLE IF EXISTS `client_jobschedule2submission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_jobschedule2submission` (
  `scheduleid` bigint(20) NOT NULL,
  `submissionid` bigint(11) NOT NULL,
  PRIMARY KEY (`submissionid`),
  UNIQUE KEY `scheduleid` (`scheduleid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_jobschedule2submission`
--

LOCK TABLES `client_jobschedule2submission` WRITE;
/*!40000 ALTER TABLE `client_jobschedule2submission` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_jobschedule2submission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_library`
--

DROP TABLE IF EXISTS `client_library`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_library` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_library`
--

LOCK TABLES `client_library` WRITE;
/*!40000 ALTER TABLE `client_library` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_library` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_os`
--

DROP TABLE IF EXISTS `client_os`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_os` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `bits` tinyint(4) NOT NULL DEFAULT '32',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `version` (`version`),
  KEY `bits` (`bits`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_os`
--

LOCK TABLES `client_os` WRITE;
/*!40000 ALTER TABLE `client_os` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_os` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_site`
--

DROP TABLE IF EXISTS `client_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `osid` int(11) DEFAULT NULL,
  `systemname` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `basedirectory` varchar(512) NOT NULL,
  `lastping` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `lastping` (`lastping`),
  KEY `system` (`osid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_site`
--

LOCK TABLES `client_site` WRITE;
/*!40000 ALTER TABLE `client_site` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_site2cmake`
--

DROP TABLE IF EXISTS `client_site2cmake`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_site2cmake` (
  `siteid` int(11) DEFAULT NULL,
  `cmakeid` int(11) DEFAULT NULL,
  `path` varchar(512) DEFAULT NULL,
  KEY `siteid` (`siteid`),
  KEY `version` (`cmakeid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_site2cmake`
--

LOCK TABLES `client_site2cmake` WRITE;
/*!40000 ALTER TABLE `client_site2cmake` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_site2cmake` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_site2compiler`
--

DROP TABLE IF EXISTS `client_site2compiler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_site2compiler` (
  `siteid` int(11) DEFAULT NULL,
  `compilerid` int(11) DEFAULT NULL,
  `command` varchar(512) DEFAULT NULL,
  `generator` varchar(255) NOT NULL,
  KEY `siteid` (`siteid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_site2compiler`
--

LOCK TABLES `client_site2compiler` WRITE;
/*!40000 ALTER TABLE `client_site2compiler` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_site2compiler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_site2library`
--

DROP TABLE IF EXISTS `client_site2library`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_site2library` (
  `siteid` int(11) DEFAULT NULL,
  `libraryid` int(11) DEFAULT NULL,
  `path` varchar(512) DEFAULT NULL,
  `include` varchar(512) NOT NULL,
  KEY `siteid` (`siteid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_site2library`
--

LOCK TABLES `client_site2library` WRITE;
/*!40000 ALTER TABLE `client_site2library` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_site2library` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_site2program`
--

DROP TABLE IF EXISTS `client_site2program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_site2program` (
  `siteid` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `version` varchar(30) NOT NULL,
  `path` varchar(512) NOT NULL,
  KEY `siteid` (`siteid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_site2program`
--

LOCK TABLES `client_site2program` WRITE;
/*!40000 ALTER TABLE `client_site2program` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_site2program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_site2project`
--

DROP TABLE IF EXISTS `client_site2project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_site2project` (
  `projectid` int(11) DEFAULT NULL,
  `siteid` int(11) DEFAULT NULL,
  KEY `siteid` (`siteid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_site2project`
--

LOCK TABLES `client_site2project` WRITE;
/*!40000 ALTER TABLE `client_site2project` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_site2project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configure`
--

DROP TABLE IF EXISTS `configure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configure` (
  `buildid` int(11) NOT NULL DEFAULT '0',
  `starttime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `endtime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `command` text NOT NULL,
  `log` mediumtext NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `warnings` smallint(6) DEFAULT '-1',
  KEY `buildid` (`buildid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configure`
--

LOCK TABLES `configure` WRITE;
/*!40000 ALTER TABLE `configure` DISABLE KEYS */;
/*!40000 ALTER TABLE `configure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configureerror`
--

DROP TABLE IF EXISTS `configureerror`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configureerror` (
  `buildid` bigint(20) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `text` text NOT NULL,
  KEY `buildid` (`buildid`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configureerror`
--

LOCK TABLES `configureerror` WRITE;
/*!40000 ALTER TABLE `configureerror` DISABLE KEYS */;
/*!40000 ALTER TABLE `configureerror` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configureerrordiff`
--

DROP TABLE IF EXISTS `configureerrordiff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configureerrordiff` (
  `buildid` bigint(20) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `difference` int(11) NOT NULL,
  KEY `buildid` (`buildid`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configureerrordiff`
--

LOCK TABLES `configureerrordiff` WRITE;
/*!40000 ALTER TABLE `configureerrordiff` DISABLE KEYS */;
/*!40000 ALTER TABLE `configureerrordiff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coverage`
--

DROP TABLE IF EXISTS `coverage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coverage` (
  `buildid` int(11) NOT NULL DEFAULT '0',
  `fileid` int(11) NOT NULL DEFAULT '0',
  `covered` tinyint(4) NOT NULL DEFAULT '0',
  `loctested` int(11) NOT NULL DEFAULT '0',
  `locuntested` int(11) NOT NULL DEFAULT '0',
  `branchstested` int(11) NOT NULL DEFAULT '0',
  `branchsuntested` int(11) NOT NULL DEFAULT '0',
  `functionstested` int(11) NOT NULL DEFAULT '0',
  `functionsuntested` int(11) NOT NULL DEFAULT '0',
  KEY `buildid` (`buildid`),
  KEY `fileid` (`fileid`),
  KEY `covered` (`covered`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 MAX_ROWS=4294967295 AVG_ROW_LENGTH=3458;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coverage`
--

LOCK TABLES `coverage` WRITE;
/*!40000 ALTER TABLE `coverage` DISABLE KEYS */;
/*!40000 ALTER TABLE `coverage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coveragefile`
--

DROP TABLE IF EXISTS `coveragefile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coveragefile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullpath` varchar(255) NOT NULL DEFAULT '',
  `file` longblob,
  `crc32` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fullpath` (`fullpath`),
  KEY `crc32` (`crc32`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 MAX_ROWS=4294967295 AVG_ROW_LENGTH=3458;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coveragefile`
--

LOCK TABLES `coveragefile` WRITE;
/*!40000 ALTER TABLE `coveragefile` DISABLE KEYS */;
/*!40000 ALTER TABLE `coveragefile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coveragefile2user`
--

DROP TABLE IF EXISTS `coveragefile2user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coveragefile2user` (
  `fileid` bigint(20) NOT NULL,
  `userid` bigint(20) NOT NULL,
  `position` tinyint(4) NOT NULL,
  KEY `coveragefileid` (`fileid`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coveragefile2user`
--

LOCK TABLES `coveragefile2user` WRITE;
/*!40000 ALTER TABLE `coveragefile2user` DISABLE KEYS */;
/*!40000 ALTER TABLE `coveragefile2user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coveragefilelog`
--

DROP TABLE IF EXISTS `coveragefilelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coveragefilelog` (
  `buildid` int(11) NOT NULL DEFAULT '0',
  `fileid` int(11) NOT NULL DEFAULT '0',
  `log` longblob NOT NULL,
  KEY `fileid` (`fileid`),
  KEY `buildid` (`buildid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 MAX_ROWS=4294967295 AVG_ROW_LENGTH=3458;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coveragefilelog`
--

LOCK TABLES `coveragefilelog` WRITE;
/*!40000 ALTER TABLE `coveragefilelog` DISABLE KEYS */;
/*!40000 ALTER TABLE `coveragefilelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coveragefilepriority`
--

DROP TABLE IF EXISTS `coveragefilepriority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coveragefilepriority` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `priority` tinyint(4) NOT NULL,
  `fullpath` varchar(255) NOT NULL,
  `projectid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `priority` (`priority`),
  KEY `fullpath` (`fullpath`),
  KEY `projectid` (`projectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coveragefilepriority`
--

LOCK TABLES `coveragefilepriority` WRITE;
/*!40000 ALTER TABLE `coveragefilepriority` DISABLE KEYS */;
/*!40000 ALTER TABLE `coveragefilepriority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coveragesummary`
--

DROP TABLE IF EXISTS `coveragesummary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coveragesummary` (
  `buildid` int(11) NOT NULL DEFAULT '0',
  `loctested` int(11) NOT NULL DEFAULT '0',
  `locuntested` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`buildid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coveragesummary`
--

LOCK TABLES `coveragesummary` WRITE;
/*!40000 ALTER TABLE `coveragesummary` DISABLE KEYS */;
/*!40000 ALTER TABLE `coveragesummary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coveragesummarydiff`
--

DROP TABLE IF EXISTS `coveragesummarydiff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coveragesummarydiff` (
  `buildid` bigint(20) NOT NULL,
  `loctested` int(11) NOT NULL DEFAULT '0',
  `locuntested` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`buildid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coveragesummarydiff`
--

LOCK TABLES `coveragesummarydiff` WRITE;
/*!40000 ALTER TABLE `coveragesummarydiff` DISABLE KEYS */;
/*!40000 ALTER TABLE `coveragesummarydiff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dailyupdate`
--

DROP TABLE IF EXISTS `dailyupdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dailyupdate` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  `date` date NOT NULL,
  `command` text NOT NULL,
  `type` varchar(4) NOT NULL DEFAULT '',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `revision` varchar(60) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `projectid` (`projectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dailyupdate`
--

LOCK TABLES `dailyupdate` WRITE;
/*!40000 ALTER TABLE `dailyupdate` DISABLE KEYS */;
/*!40000 ALTER TABLE `dailyupdate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dailyupdatefile`
--

DROP TABLE IF EXISTS `dailyupdatefile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dailyupdatefile` (
  `dailyupdateid` int(11) NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `checkindate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `author` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `log` text NOT NULL,
  `revision` varchar(60) NOT NULL DEFAULT '0',
  `priorrevision` varchar(60) NOT NULL DEFAULT '0',
  KEY `dailyupdateid` (`dailyupdateid`),
  KEY `author` (`author`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dailyupdatefile`
--

LOCK TABLES `dailyupdatefile` WRITE;
/*!40000 ALTER TABLE `dailyupdatefile` DISABLE KEYS */;
/*!40000 ALTER TABLE `dailyupdatefile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dynamicanalysis`
--

DROP TABLE IF EXISTS `dynamicanalysis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dynamicanalysis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `buildid` int(11) NOT NULL DEFAULT '0',
  `status` varchar(10) NOT NULL DEFAULT '',
  `checker` varchar(60) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `fullcommandline` varchar(255) NOT NULL DEFAULT '',
  `log` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `buildid` (`buildid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dynamicanalysis`
--

LOCK TABLES `dynamicanalysis` WRITE;
/*!40000 ALTER TABLE `dynamicanalysis` DISABLE KEYS */;
/*!40000 ALTER TABLE `dynamicanalysis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dynamicanalysisdefect`
--

DROP TABLE IF EXISTS `dynamicanalysisdefect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dynamicanalysisdefect` (
  `dynamicanalysisid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(50) NOT NULL DEFAULT '',
  `value` int(11) NOT NULL DEFAULT '0',
  KEY `buildid` (`dynamicanalysisid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dynamicanalysisdefect`
--

LOCK TABLES `dynamicanalysisdefect` WRITE;
/*!40000 ALTER TABLE `dynamicanalysisdefect` DISABLE KEYS */;
/*!40000 ALTER TABLE `dynamicanalysisdefect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `errorlog`
--

DROP TABLE IF EXISTS `errorlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `errorlog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  `buildid` bigint(20) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type` tinyint(4) NOT NULL,
  `description` mediumtext NOT NULL,
  `resourcetype` tinyint(4) NOT NULL DEFAULT '0',
  `resourceid` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `resourceid` (`resourceid`),
  KEY `date` (`date`),
  KEY `resourcetype` (`resourcetype`),
  KEY `projectid` (`projectid`),
  KEY `buildid` (`buildid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `errorlog`
--

LOCK TABLES `errorlog` WRITE;
/*!40000 ALTER TABLE `errorlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `errorlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feed`
--

DROP TABLE IF EXISTS `feed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `buildid` bigint(20) NOT NULL,
  `type` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `projectid` (`projectid`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feed`
--

LOCK TABLES `feed` WRITE;
/*!40000 ALTER TABLE `feed` DISABLE KEYS */;
/*!40000 ALTER TABLE `feed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filesum`
--

DROP TABLE IF EXISTS `filesum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filesum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `md5sum` varchar(32) NOT NULL,
  `contents` longblob,
  PRIMARY KEY (`id`),
  KEY `md5sum` (`md5sum`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filesum`
--

LOCK TABLES `filesum` WRITE;
/*!40000 ALTER TABLE `filesum` DISABLE KEYS */;
/*!40000 ALTER TABLE `filesum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` longblob NOT NULL,
  `extension` tinytext NOT NULL,
  `checksum` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `checksum` (`checksum`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 MAX_ROWS=4294967295 AVG_ROW_LENGTH=3458;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image`
--

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `label`
--

DROP TABLE IF EXISTS `label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `label` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `text` (`text`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `label`
--

LOCK TABLES `label` WRITE;
/*!40000 ALTER TABLE `label` DISABLE KEYS */;
/*!40000 ALTER TABLE `label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `label2build`
--

DROP TABLE IF EXISTS `label2build`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `label2build` (
  `labelid` bigint(20) NOT NULL,
  `buildid` bigint(20) NOT NULL,
  PRIMARY KEY (`labelid`,`buildid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `label2build`
--

LOCK TABLES `label2build` WRITE;
/*!40000 ALTER TABLE `label2build` DISABLE KEYS */;
/*!40000 ALTER TABLE `label2build` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `label2buildfailure`
--

DROP TABLE IF EXISTS `label2buildfailure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `label2buildfailure` (
  `labelid` bigint(20) NOT NULL,
  `buildfailureid` bigint(20) NOT NULL,
  PRIMARY KEY (`labelid`,`buildfailureid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `label2buildfailure`
--

LOCK TABLES `label2buildfailure` WRITE;
/*!40000 ALTER TABLE `label2buildfailure` DISABLE KEYS */;
/*!40000 ALTER TABLE `label2buildfailure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `label2coveragefile`
--

DROP TABLE IF EXISTS `label2coveragefile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `label2coveragefile` (
  `labelid` bigint(20) NOT NULL,
  `buildid` bigint(20) NOT NULL,
  `coveragefileid` bigint(20) NOT NULL,
  PRIMARY KEY (`labelid`,`buildid`,`coveragefileid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `label2coveragefile`
--

LOCK TABLES `label2coveragefile` WRITE;
/*!40000 ALTER TABLE `label2coveragefile` DISABLE KEYS */;
/*!40000 ALTER TABLE `label2coveragefile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `label2dynamicanalysis`
--

DROP TABLE IF EXISTS `label2dynamicanalysis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `label2dynamicanalysis` (
  `labelid` bigint(20) NOT NULL,
  `dynamicanalysisid` bigint(20) NOT NULL,
  PRIMARY KEY (`labelid`,`dynamicanalysisid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `label2dynamicanalysis`
--

LOCK TABLES `label2dynamicanalysis` WRITE;
/*!40000 ALTER TABLE `label2dynamicanalysis` DISABLE KEYS */;
/*!40000 ALTER TABLE `label2dynamicanalysis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `label2test`
--

DROP TABLE IF EXISTS `label2test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `label2test` (
  `labelid` bigint(20) NOT NULL,
  `buildid` bigint(20) NOT NULL,
  `testid` bigint(20) NOT NULL,
  PRIMARY KEY (`labelid`,`buildid`,`testid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `label2test`
--

LOCK TABLES `label2test` WRITE;
/*!40000 ALTER TABLE `label2test` DISABLE KEYS */;
/*!40000 ALTER TABLE `label2test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `label2update`
--

DROP TABLE IF EXISTS `label2update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `label2update` (
  `labelid` bigint(20) NOT NULL,
  `updateid` bigint(20) NOT NULL,
  PRIMARY KEY (`labelid`,`updateid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `label2update`
--

LOCK TABLES `label2update` WRITE;
/*!40000 ALTER TABLE `label2update` DISABLE KEYS */;
/*!40000 ALTER TABLE `label2update` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `labelemail`
--

DROP TABLE IF EXISTS `labelemail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `labelemail` (
  `projectid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `labelid` bigint(20) NOT NULL,
  KEY `projectid` (`projectid`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `labelemail`
--

LOCK TABLES `labelemail` WRITE;
/*!40000 ALTER TABLE `labelemail` DISABLE KEYS */;
/*!40000 ALTER TABLE `labelemail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `measurement`
--

DROP TABLE IF EXISTS `measurement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `measurement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `testpage` tinyint(1) NOT NULL,
  `summarypage` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `projectid` (`projectid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `measurement`
--

LOCK TABLES `measurement` WRITE;
/*!40000 ALTER TABLE `measurement` DISABLE KEYS */;
/*!40000 ALTER TABLE `measurement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note`
--

DROP TABLE IF EXISTS `note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `note` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `text` mediumtext NOT NULL,
  `name` varchar(255) NOT NULL,
  `crc32` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `crc32` (`crc32`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 MAX_ROWS=4294967295 AVG_ROW_LENGTH=3458;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note`
--

LOCK TABLES `note` WRITE;
/*!40000 ALTER TABLE `note` DISABLE KEYS */;
/*!40000 ALTER TABLE `note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `homeurl` varchar(255) NOT NULL DEFAULT '',
  `cvsurl` varchar(255) NOT NULL DEFAULT '',
  `bugtrackerurl` varchar(255) NOT NULL DEFAULT '',
  `bugtrackerfileurl` varchar(255) NOT NULL DEFAULT '',
  `documentationurl` varchar(255) NOT NULL DEFAULT '',
  `imageid` int(11) NOT NULL DEFAULT '0',
  `public` tinyint(4) NOT NULL DEFAULT '1',
  `coveragethreshold` smallint(6) NOT NULL DEFAULT '70',
  `testingdataurl` varchar(255) NOT NULL DEFAULT '',
  `nightlytime` varchar(50) NOT NULL DEFAULT '00:00:00',
  `googletracker` varchar(50) NOT NULL DEFAULT '',
  `emaillowcoverage` tinyint(4) NOT NULL DEFAULT '0',
  `emailtesttimingchanged` tinyint(4) NOT NULL DEFAULT '0',
  `emailbrokensubmission` tinyint(4) NOT NULL DEFAULT '1',
  `emailredundantfailures` tinyint(4) NOT NULL DEFAULT '0',
  `emailadministrator` tinyint(4) NOT NULL DEFAULT '1',
  `showipaddresses` tinyint(4) NOT NULL DEFAULT '1',
  `cvsviewertype` varchar(10) DEFAULT NULL,
  `testtimestd` float(3,1) DEFAULT '4.0',
  `testtimestdthreshold` float(3,1) DEFAULT '1.0',
  `showtesttime` tinyint(4) DEFAULT '0',
  `testtimemaxstatus` tinyint(4) DEFAULT '3',
  `emailmaxitems` tinyint(4) DEFAULT '5',
  `emailmaxchars` int(11) DEFAULT '255',
  `displaylabels` tinyint(4) DEFAULT '1',
  `autoremovetimeframe` int(11) DEFAULT '0',
  `autoremovemaxbuilds` int(11) DEFAULT '300',
  `uploadquota` bigint(20) DEFAULT '0',
  `webapikey` varchar(40) DEFAULT NULL,
  `tokenduration` int(11) DEFAULT NULL,
  `showcoveragecode` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `public` (`public`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` VALUES (1,'netcdf-c','','','','','','',0,1,70,'','01:00:00 UTC','',0,0,0,0,0,0,'github',4.0,1.0,1,3,5,255,0,60,500,1073741824,'QZLmrazRbv2Citacqgqhl6kMIVAsLpVsewFvx5cz',NULL,1),(2,'netcdf-cxx4','','','','','','',0,1,70,'','01:00:00 UTC','',0,0,0,0,0,0,'github',4.0,1.0,1,3,5,255,0,60,500,1073741824,'4iad2bAYDPjG1EnzUBzSlxDjE2fGsq8ny8rq9ReD',NULL,1),(3,'netcdf-fortran','','','','','','',0,1,70,'','01:00:00 UTC','',0,0,0,0,0,0,'github',4.0,1.0,1,3,5,255,0,60,500,1073741824,'78Rp9DnVzg1PLDYgAK4As1yg7Aot2ncZlUfkos6O',NULL,1);
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project2repositories`
--

DROP TABLE IF EXISTS `project2repositories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project2repositories` (
  `projectid` int(11) NOT NULL,
  `repositoryid` int(11) NOT NULL,
  PRIMARY KEY (`projectid`,`repositoryid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project2repositories`
--

LOCK TABLES `project2repositories` WRITE;
/*!40000 ALTER TABLE `project2repositories` DISABLE KEYS */;
INSERT INTO `project2repositories` VALUES (1,1),(2,2),(3,3);
/*!40000 ALTER TABLE `project2repositories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectjobscript`
--

DROP TABLE IF EXISTS `projectjobscript`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectjobscript` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  `script` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `projectid` (`projectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectjobscript`
--

LOCK TABLES `projectjobscript` WRITE;
/*!40000 ALTER TABLE `projectjobscript` DISABLE KEYS */;
/*!40000 ALTER TABLE `projectjobscript` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectrobot`
--

DROP TABLE IF EXISTS `projectrobot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectrobot` (
  `projectid` int(11) NOT NULL,
  `robotname` varchar(255) NOT NULL,
  `authorregex` varchar(512) NOT NULL,
  KEY `projectid` (`projectid`),
  KEY `robotname` (`robotname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectrobot`
--

LOCK TABLES `projectrobot` WRITE;
/*!40000 ALTER TABLE `projectrobot` DISABLE KEYS */;
/*!40000 ALTER TABLE `projectrobot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repositories`
--

DROP TABLE IF EXISTS `repositories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repositories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `branch` varchar(60) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repositories`
--

LOCK TABLES `repositories` WRITE;
/*!40000 ALTER TABLE `repositories` DISABLE KEYS */;
INSERT INTO `repositories` VALUES (1,'https://github.com/Unidata/netcdf-c','','',''),(2,'http://github.com/Unidata/netcdf-cxx4','','',''),(3,'http://github.com/Unidata/netcdf-fortran','','','');
/*!40000 ALTER TABLE `repositories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site`
--

DROP TABLE IF EXISTS `site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `ip` varchar(255) NOT NULL DEFAULT '',
  `latitude` varchar(10) NOT NULL DEFAULT '',
  `longitude` varchar(10) NOT NULL DEFAULT '',
  `outoforder` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site`
--

LOCK TABLES `site` WRITE;
/*!40000 ALTER TABLE `site` DISABLE KEYS */;
/*!40000 ALTER TABLE `site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site2user`
--

DROP TABLE IF EXISTS `site2user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site2user` (
  `siteid` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  KEY `siteid` (`siteid`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site2user`
--

LOCK TABLES `site2user` WRITE;
/*!40000 ALTER TABLE `site2user` DISABLE KEYS */;
/*!40000 ALTER TABLE `site2user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `siteinformation`
--

DROP TABLE IF EXISTS `siteinformation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `siteinformation` (
  `siteid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `processoris64bits` tinyint(4) NOT NULL DEFAULT '-1',
  `processorvendor` varchar(255) NOT NULL DEFAULT 'NA',
  `processorvendorid` varchar(255) NOT NULL DEFAULT 'NA',
  `processorfamilyid` int(11) NOT NULL DEFAULT '-1',
  `processormodelid` int(11) NOT NULL DEFAULT '-1',
  `processorcachesize` int(11) NOT NULL DEFAULT '-1',
  `numberlogicalcpus` tinyint(4) NOT NULL DEFAULT '-1',
  `numberphysicalcpus` tinyint(4) NOT NULL DEFAULT '-1',
  `totalvirtualmemory` int(11) NOT NULL DEFAULT '-1',
  `totalphysicalmemory` int(11) NOT NULL DEFAULT '-1',
  `logicalprocessorsperphysical` int(11) NOT NULL DEFAULT '-1',
  `processorclockfrequency` int(11) NOT NULL DEFAULT '-1',
  `description` varchar(255) NOT NULL DEFAULT 'NA',
  KEY `siteid` (`siteid`,`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `siteinformation`
--

LOCK TABLES `siteinformation` WRITE;
/*!40000 ALTER TABLE `siteinformation` DISABLE KEYS */;
/*!40000 ALTER TABLE `siteinformation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission`
--

DROP TABLE IF EXISTS `submission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `submission` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(500) NOT NULL,
  `projectid` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT '0',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `filemd5sum` varchar(32) NOT NULL DEFAULT '',
  `lastupdated` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `created` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `started` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `finished` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  PRIMARY KEY (`id`),
  KEY `projectid` (`projectid`),
  KEY `status` (`status`),
  KEY `finished` (`finished`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission`
--

LOCK TABLES `submission` WRITE;
/*!40000 ALTER TABLE `submission` DISABLE KEYS */;
/*!40000 ALTER TABLE `submission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission2ip`
--

DROP TABLE IF EXISTS `submission2ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `submission2ip` (
  `submissionid` bigint(11) NOT NULL,
  `ip` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`submissionid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission2ip`
--

LOCK TABLES `submission2ip` WRITE;
/*!40000 ALTER TABLE `submission2ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `submission2ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submissionprocessor`
--

DROP TABLE IF EXISTS `submissionprocessor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `submissionprocessor` (
  `projectid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `lastupdated` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `locked` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  PRIMARY KEY (`projectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submissionprocessor`
--

LOCK TABLES `submissionprocessor` WRITE;
/*!40000 ALTER TABLE `submissionprocessor` DISABLE KEYS */;
/*!40000 ALTER TABLE `submissionprocessor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subproject`
--

DROP TABLE IF EXISTS `subproject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subproject` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `projectid` int(11) NOT NULL,
  `starttime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `endtime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  PRIMARY KEY (`id`),
  KEY `projectid` (`projectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subproject`
--

LOCK TABLES `subproject` WRITE;
/*!40000 ALTER TABLE `subproject` DISABLE KEYS */;
/*!40000 ALTER TABLE `subproject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subproject2build`
--

DROP TABLE IF EXISTS `subproject2build`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subproject2build` (
  `subprojectid` int(11) NOT NULL,
  `buildid` bigint(20) NOT NULL,
  PRIMARY KEY (`buildid`),
  KEY `subprojectid` (`subprojectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subproject2build`
--

LOCK TABLES `subproject2build` WRITE;
/*!40000 ALTER TABLE `subproject2build` DISABLE KEYS */;
/*!40000 ALTER TABLE `subproject2build` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subproject2subproject`
--

DROP TABLE IF EXISTS `subproject2subproject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subproject2subproject` (
  `subprojectid` int(11) NOT NULL,
  `dependsonid` int(11) NOT NULL,
  `starttime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `endtime` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  KEY `subprojectid` (`subprojectid`),
  KEY `dependsonid` (`dependsonid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subproject2subproject`
--

LOCK TABLES `subproject2subproject` WRITE;
/*!40000 ALTER TABLE `subproject2subproject` DISABLE KEYS */;
/*!40000 ALTER TABLE `subproject2subproject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `summaryemail`
--

DROP TABLE IF EXISTS `summaryemail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `summaryemail` (
  `buildid` bigint(20) NOT NULL,
  `date` date NOT NULL,
  `groupid` smallint(6) NOT NULL,
  KEY `date` (`date`),
  KEY `groupid` (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `summaryemail`
--

LOCK TABLES `summaryemail` WRITE;
/*!40000 ALTER TABLE `summaryemail` DISABLE KEYS */;
/*!40000 ALTER TABLE `summaryemail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  `crc32` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `command` text NOT NULL,
  `details` text NOT NULL,
  `output` mediumblob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `projectid` (`projectid`),
  KEY `crc32` (`crc32`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 MAX_ROWS=4294967295 AVG_ROW_LENGTH=3458;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test`
--

LOCK TABLES `test` WRITE;
/*!40000 ALTER TABLE `test` DISABLE KEYS */;
/*!40000 ALTER TABLE `test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test2image`
--

DROP TABLE IF EXISTS `test2image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test2image` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `imgid` int(11) NOT NULL,
  `testid` int(11) NOT NULL,
  `role` tinytext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `imgid` (`imgid`),
  KEY `testid` (`testid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test2image`
--

LOCK TABLES `test2image` WRITE;
/*!40000 ALTER TABLE `test2image` DISABLE KEYS */;
/*!40000 ALTER TABLE `test2image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testdiff`
--

DROP TABLE IF EXISTS `testdiff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testdiff` (
  `buildid` bigint(20) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `difference_positive` int(11) NOT NULL,
  `difference_negative` int(11) NOT NULL,
  KEY `buildid` (`buildid`),
  KEY `type` (`type`),
  KEY `difference_positive` (`difference_positive`),
  KEY `difference_negative` (`difference_negative`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testdiff`
--

LOCK TABLES `testdiff` WRITE;
/*!40000 ALTER TABLE `testdiff` DISABLE KEYS */;
/*!40000 ALTER TABLE `testdiff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testmeasurement`
--

DROP TABLE IF EXISTS `testmeasurement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testmeasurement` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `testid` bigint(20) NOT NULL,
  `name` varchar(70) NOT NULL,
  `type` varchar(70) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `testid` (`testid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testmeasurement`
--

LOCK TABLES `testmeasurement` WRITE;
/*!40000 ALTER TABLE `testmeasurement` DISABLE KEYS */;
/*!40000 ALTER TABLE `testmeasurement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `updatefile`
--

DROP TABLE IF EXISTS `updatefile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `updatefile` (
  `updateid` int(11) NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `checkindate` timestamp NOT NULL DEFAULT '1980-01-01 07:00:00',
  `author` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `committer` varchar(255) NOT NULL DEFAULT '',
  `committeremail` varchar(255) NOT NULL DEFAULT '',
  `log` text NOT NULL,
  `revision` varchar(60) NOT NULL DEFAULT '0',
  `priorrevision` varchar(60) NOT NULL DEFAULT '0',
  `status` varchar(12) NOT NULL DEFAULT '',
  KEY `updateid` (`updateid`),
  KEY `author` (`author`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `updatefile`
--

LOCK TABLES `updatefile` WRITE;
/*!40000 ALTER TABLE `updatefile` DISABLE KEYS */;
/*!40000 ALTER TABLE `updatefile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uploadfile`
--

DROP TABLE IF EXISTS `uploadfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uploadfile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `filesize` int(11) NOT NULL DEFAULT '0',
  `sha1sum` varchar(40) NOT NULL,
  `isurl` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sha1sum` (`sha1sum`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uploadfile`
--

LOCK TABLES `uploadfile` WRITE;
/*!40000 ALTER TABLE `uploadfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `uploadfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(40) NOT NULL DEFAULT '',
  `firstname` varchar(40) NOT NULL DEFAULT '',
  `lastname` varchar(40) NOT NULL DEFAULT '',
  `institution` varchar(255) NOT NULL DEFAULT '',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `cookiekey` varchar(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin@localhost','5f4dcc3b5aa765d61d8327deb882cf99','administrator','','',1,'');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user2project`
--

DROP TABLE IF EXISTS `user2project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user2project` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `projectid` int(11) NOT NULL DEFAULT '0',
  `role` int(11) NOT NULL DEFAULT '0',
  `cvslogin` varchar(50) NOT NULL DEFAULT '',
  `emailtype` tinyint(4) NOT NULL DEFAULT '0',
  `emailcategory` tinyint(4) NOT NULL DEFAULT '62',
  `emailsuccess` tinyint(4) NOT NULL DEFAULT '0',
  `emailmissingsites` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`,`projectid`),
  KEY `cvslogin` (`cvslogin`),
  KEY `emailtype` (`emailtype`),
  KEY `emailsucess` (`emailsuccess`),
  KEY `emailmissingsites` (`emailmissingsites`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user2project`
--

LOCK TABLES `user2project` WRITE;
/*!40000 ALTER TABLE `user2project` DISABLE KEYS */;
INSERT INTO `user2project` VALUES (1,1,2,'',3,126,0,0),(1,2,2,'',3,126,0,0),(1,3,2,'',3,126,0,0);
/*!40000 ALTER TABLE `user2project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user2repository`
--

DROP TABLE IF EXISTS `user2repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user2repository` (
  `userid` int(11) NOT NULL,
  `credential` varchar(255) NOT NULL,
  `projectid` int(11) NOT NULL DEFAULT '0',
  KEY `userid` (`userid`),
  KEY `credential` (`credential`),
  KEY `projectid` (`projectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user2repository`
--

LOCK TABLES `user2repository` WRITE;
/*!40000 ALTER TABLE `user2repository` DISABLE KEYS */;
/*!40000 ALTER TABLE `user2repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userstatistics`
--

DROP TABLE IF EXISTS `userstatistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userstatistics` (
  `userid` int(11) NOT NULL,
  `projectid` smallint(6) NOT NULL,
  `checkindate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `totalupdatedfiles` bigint(20) NOT NULL,
  `totalbuilds` bigint(20) NOT NULL,
  `nfixedwarnings` bigint(20) NOT NULL,
  `nfailedwarnings` bigint(20) NOT NULL,
  `nfixederrors` bigint(20) NOT NULL,
  `nfailederrors` bigint(20) NOT NULL,
  `nfixedtests` bigint(20) NOT NULL,
  `nfailedtests` bigint(20) NOT NULL,
  KEY `userid` (`userid`),
  KEY `projectid` (`projectid`),
  KEY `checkindate` (`checkindate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userstatistics`
--

LOCK TABLES `userstatistics` WRITE;
/*!40000 ALTER TABLE `userstatistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `userstatistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usertemp`
--

DROP TABLE IF EXISTS `usertemp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usertemp` (
  `email` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(40) NOT NULL DEFAULT '',
  `firstname` varchar(40) NOT NULL DEFAULT '',
  `lastname` varchar(40) NOT NULL DEFAULT '',
  `institution` varchar(255) NOT NULL DEFAULT '',
  `registrationdate` datetime NOT NULL,
  `registrationkey` varchar(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`email`),
  KEY `registrationdate` (`registrationdate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usertemp`
--

LOCK TABLES `usertemp` WRITE;
/*!40000 ALTER TABLE `usertemp` DISABLE KEYS */;
/*!40000 ALTER TABLE `usertemp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `version`
--

DROP TABLE IF EXISTS `version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `version` (
  `major` tinyint(4) NOT NULL,
  `minor` tinyint(4) NOT NULL,
  `patch` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version`
--

LOCK TABLES `version` WRITE;
/*!40000 ALTER TABLE `version` DISABLE KEYS */;
INSERT INTO `version` VALUES (2,2,0);
/*!40000 ALTER TABLE `version` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-01 12:59:03
